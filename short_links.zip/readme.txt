Системні вимоги
1) php => 5.4
2) MySQL(MariaDb) => 5.1

Інструкція з встановлення
1) Розпакувати архів в корні домена
2) Створити базу даних і користувача для неї
3) Прописати налаштування в файлі index.php

	$servername = "localhost"; //server name
    	$username = "link";        //user name
    	$password = "5G4k1Q9x";    //user password
    	$dbname = "link";          //db name

4) Імпортувати в базу даних файл short_links.sql
5) Скрипт встановлений і можна використовувати.

Author: Roman Matviy
https://matviy.pp.ua